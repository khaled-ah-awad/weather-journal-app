// Setup An Empty Object To Act As Endpoint 
const projectData = [];

// Include Express + Body-Parser + CORS
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Start Up An Instance 
const app = express();

/* Middleware*/

// Configuring To Use Body-Parser As A Middleware To Parse Data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Configuring CORS For Cross Origin Allowence
app.use(cors());

// Initialize Main Project Folder
app.use(express.static('website'));

// Set Port To 1414
const port = 1414;

// Set Server To Port + Log A Testing Message In Terminal
const server = app.listen(port, () => console.log(`Server Running Pretty On localhose:${port}`));

/* Get & POST Routes */

// GET Function
app.get('/all', (req, res) => res.send(projectData));

// POST Function
app.post('/add', (req, res) => {
    injectedData = {
        date: req.body.date,
        temp: req.body.temp,
        feelings: req.body.feelings
    };
    projectData.push(injectedData);
    res.send(projectData);
});
