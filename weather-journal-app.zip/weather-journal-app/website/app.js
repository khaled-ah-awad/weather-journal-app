/** Global Variables **/

// Declare Variables For Input Fields
const owBaseURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const owApiKey  = '&appid=c95fb87de0982115b49f1a73bea66f2f&units=imperial';
const inZipCode = document.querySelector('#zip');
const inFeeling = document.querySelector('#feelings');
const btnToGen  = document.querySelector('#generate');

// Declare Variables For Output Fields
const displayDate = document.querySelector('#date');
const displayTemp = document.querySelector('#temp');
const displayFeel = document.querySelector('#content');

// Create New Date Dynamically
let d = new Date();
let newDate = d.getMonth()+ 1 +'/'+ d.getDate()+'/'+ d.getFullYear();

// GET Data Function
const getWeatherData = async (owBaseURL, zipCodeValue, owApiKey)=>{
    const res = await fetch(owBaseURL+zipCodeValue+owApiKey);
    try {
      const data = await res.json();
      return data;
    }
    catch(err) {
      console.error("Error : ", err);
    }
}

/* Function to POST data */
const postWeatherData = async (url='' ,data={}) => {
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data), // Matching With Headers Type
    });
    try {
        const newData = await response.json();
        console.log(newData)
        return newData;
    }catch(err) {
        console.error("ERROR : ", err);
    }
  }

// Function To Update UI Of App  
const updateUI = async () => {

  const req = await fetch('/all');
  console.log(req.body);
  
  try{

    const weatherData = await req.json();
    displayDate.innerHTML = weatherData[weatherData.length - 1].date;
    displayTemp.innerHTML = weatherData[weatherData.length - 1].temp;
    displayFeel.innerHTML = weatherData[weatherData.length - 1].feelings;
  
    }catch(err){
    
        console.error("ERROR : ", err);
  
    }
}
// Listen To Button To Perform Action
btnToGen.addEventListener('click', async() => {

    /* Call-Back Function To DO */
    
    // Decalre Varibales To Assign Values
    const zipCodeValue = inZipCode.value;
    const feelingValue = inFeeling.value;

    // Execute Main Functions To Update UI
    const weatherData = await getWeatherData(owBaseURL, zipCodeValue, owApiKey);
    await postWeatherData('/add', {
        date: newDate,
        temp: weatherData.main.temp, 
        feelings: feelingValue
    });
    await updateUI();
});